INSERT INTO Course(CourseId,Title,Fees,Description,Trainer,Start_date) values(1001,'ASP Web API',6000.0,'Web API is a Technology used to create RESTful API','sam','2021-08-25');
INSERT INTO Course(CourseId,Title,Fees,Description,Trainer,Start_date) values(1002,'.Net Core',3000.0,'.Net core is a used for creating cross platform application','Joe','2021-02-27');
INSERT INTO Student(StudentId,EnrollmentId,CourseId) values(5002,2, 1002);
INSERT INTO Trainer(TrainerId,Password) values(1,'sam123');
